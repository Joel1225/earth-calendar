# Earth Calendar — specification (draft)

## 1. Purpose

Earth Calendar is a month-free civil date system. A date is written as:

`YEAR\DDD`

`YEAR` is an integer using astronomical year numbering. `DDD` is the ordinal day of the Earth Calendar year, zero-padded to three digits.

Examples:
- `11726\001`
- `11726\318`
- `00000\063`
- `-4798\063`

## 2. Epoch and calibration

The calendar uses the Holocene epoch as its conceptual historical reference. The conversion implementation is calibrated by the following user-defined reference:

**Gregorian 2026-11-04 = Earth Calendar 11726\318.**

This fixes the beginning of Earth year 11726 at 2025-12-22 00:00 UTC under the chosen solstice-boundary convention. Earth year 11727 begins at 2026-12-22 00:00 UTC.

The numeric year label is therefore determined by this calibration, not by silently substituting another published Holocene-year convention.

## 3. Year boundary

For a Gregorian seasonal cycle, find the December solstice. The next 00:00 UTC boundary after the solstice begins the next Earth Calendar year.

For example, if the solstice occurs on 21 December at 20:50 UTC, the new Earth year begins on 22 December at 00:00 UTC.

The solstice instant itself is not the boundary. The boundary is the first UTC midnight strictly after it.

## 4. Day numbering

The first UTC civil day beginning at the year boundary is day `001`. The next UTC day is `002`, and so on. A year can contain 365 or 366 days, depending on the interval between consecutive boundaries.

There are no months.

## 5. Year numbering

Earth Calendar uses astronomical year numbering:
- Year 1 is followed by year 0 when moving backwards.
- Year 0 is followed by year -1 when moving backwards.
- Negative year numbers are valid.
- There is no BC/AD gap.

## 6. UTC

All date boundaries and conversions use UTC. A user's local date may differ from the UTC date near midnight; the converter explicitly treats Gregorian input as a UTC civil date.

## 7. Astronomical accuracy and implementation limits

The included browser implementation uses the Meeus polynomial approximation for December solstices, a periodic correction series, and an approximate ΔT model to convert from Terrestrial Time to UTC.

The compact high-accuracy seasonal-event approximation is intended for Gregorian years −1000 through 3000. Outside that range, the website extrapolates and labels results approximate. This is not a claim of exact solstice reconstruction throughout the entire Holocene. Long-term changes in Earth's orbit and uncertainty in ΔT make ancient UTC boundaries progressively less certain.

A production-grade historical implementation should use a validated long-term ephemeris (for example, a suitable JPL ephemeris or a carefully validated VSOP87 implementation) and document the adopted ΔT model and uncertainty.

## 8. Reference test

The following must always hold:

`2026-11-04` → `11726\318`

And, under the year-boundary rule:

`2025-12-22` → `11726\001`

`2026-12-22` → `11727\001`

## 9. Interoperability

Recommended machine-readable representation:
- Human display: `11726\318`
- JSON: `{"year":11726,"day":318}`
- Day number is an integer in machine-readable data; zero-padding is for display.
