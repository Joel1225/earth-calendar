# Earth Calendar

A static, browser-based Earth Calendar converter designed for GitHub Pages.

## Files
- `index.html` — converter and live date display
- `SPECIFICATION.md` — draft calendar rules and accuracy notes

## Publish with GitHub Pages
1. Create a public repository named `earth-calendar`.
2. Upload `index.html` and `SPECIFICATION.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main`, folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site.

## Important
The site is a self-contained prototype. It uses a Meeus seasonal-event approximation and a ΔT estimate. Results outside Gregorian years −1000 to 3000 are explicitly approximate. Do not describe the current browser implementation as an exact Holocene-wide astronomical ephemeris.

The authoritative calibration is `2026-11-04 = 11726\318`.

## Test the reference dates
- `2025-12-22` should convert to `11726\\001`.
- `2026-11-04` should convert to `11726\\318`.
- `2026-12-22` should convert to `11727\\001`.
